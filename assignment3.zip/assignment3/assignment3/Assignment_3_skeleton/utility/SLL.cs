﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

// This class (SLL.cs) inherits LinkedListADT.cs interface that calls the methods located in this class.
// This class holds the methods for appending, prepending, inserting, replacing, deleting, retrieving, clearing and checking nodes of the singly linked list.

namespace Assignment_3_skeleton
{
    public class SLL : LinkedListADT
    {
        // VARIABLES GETTERS AND SETTERS
        public Node head { get; set; }
        public Node tail { get; set; }
        public Node current { get; set; }

        public int count = 0;

        // APPENDS newNode TO END OF LIST
        public void Append(object data)
        {
            Node newNode = new Node(data);

            // Sets the newNode data as head and tail if list is empty
            if (head == null)
            {
                head = newNode;
                tail = newNode;
                count = 1;
            }
            // Appends newNode data to end of list
            else
            {
                tail.Next = newNode;
                tail = newNode;
                count++;
            }
        }

        // CLEARS THE LIST
        public void Clear()
        {
            // clears the head value and resets count to 0
            head = null;
            count = 0;
        }

        // RETURNS BOOL IF THE LIST HAS SPECIFIED data ITEM
        public bool Contains(object data)
        {
            Node current = head;
            // Iterates through the list until a matching data object is found to return bool true or else it returns bool false if none are found
            while (current != null)
            {
                if (current.Data.Equals(data))
                {
                    return true;
                }
                current = current.Next;
            }
            return false;
        }

        // DELETES BY SPECIFIED index VALUE
        public void Delete(int index)
        {
            // Checks if the index parameter is in range of count
            if (index < 0 || index > count)
            {
                throw new ArgumentOutOfRangeException("Index is out of range.");
            }
            // Sets head to the next node in the list if index is 0 which removes the original head node and decreases count by 1
            else if (index == 0)
            {
                head = head.Next;
                count--;
            }
            // current is set to the next node until it reaches 2 nodes before the specidied index,
            // then sets the next node to the one after it which removees the current.Next node and decreases count by 1
            else
            {
                Node current = head;
                for (int i = 0; i < index - 1; i++)
                {
                    current = current.Next;
                }
                current.Next = current.Next.Next;
                count--;
            }
        }

        // CHECKS THE INDEX SIZE OF THE LIST
        public int IndexOf(object data1)
        {
            Node current = head;
            int index = 0;
            // The while loop adds 1 to count and sets current to current.Next until current is null
            while (current != null)
            {
                // If current.Data matches data1 it returns the current value of index
                if (current.Data.Equals(data1))
                {
                    return index;
                }
                current = current.Next;
                index++;
                
            }
            // If the loop is not initiated, then IndexOf() returns -1
            return -1;
        }

        // INSERTS newNode AT A SPECIFIED INDEX
        public void Insert(object data, int index)
        {
            // Checks if index parameter is out of range
            Node newNode = new Node(data);
            if (index < 0 || index > count)
            {
                throw new ArgumentOutOfRangeException("Index is out of range.");
            }
            // Prepends newNode to the list and increases vount by 1
            else if (index == 0)
            {
                newNode.Next = head;
                head = newNode;
                count++;
            }
            // current is set to the next node until it reaches 2 nodes before the specidied index,
            // then sets newNode.Next to current.Next, then replaces current.Next with newNode and increases count by 1
            else
            {
                Node current = head;
                for (int i = 0; i < index - 1; i++)
                {
                    current = current.Next;
                }
                newNode.Next = current.Next;
                current.Next = newNode;
                count++;
            }
        }

        // RETURNS A BOOL FOR IF HEAD IS EMPTY
        public bool IsEmpty()
        {
            return head == null;
        }

        // ADDS newNode TO BEGINING OF LIST
        public void Prepend(object data)
        {
            // Sets the next value of newNode to the current head and then sets head to point to newNode, then adds 1 to count
            Node newNode = new Node(data);
            newNode.Next = head;
            head = newNode;
            count++;
        }

        // REPLACES NODE DATA AT SPECIFIED INDEX
        public void Replace(object data1, int index)
        {
            // Checks if index parameter is out of range
            if (index < 0 || index > count)
            {
                throw new ArgumentOutOfRangeException("Index is out of range.");
            }
            // current is set to the next node until it reaches 1 node before the specidied index,
            // then sets current data to data1
            else
            {
                Node current = head;
                for (int i = 0; i < index; i++)
                {
                    current = current.Next;
                }
                current.Data = data1;
            }
        }

        // RETRIEVES DATA BY THE SPECIFIED INDEX
        public object Retrieve(int index)
        {
            // Checks if index parameter is out of range
            if (index < 0 || index > count)
            {
                throw new ArgumentOutOfRangeException("Index is out of range.");
            }
            // current is set to the next node until it reaches 1 node before the specidied index,
            // then returns current's Data value
            else
            {
                Node current = head;
                for (int i = 0; i < index; i++)
                {
                    current = current.Next;
                }
                return current.Data;
            }
        }

        // RETURNS THE COUNT VARIABLE
        public int Size()
        {
            return count;
        }
    }
}

